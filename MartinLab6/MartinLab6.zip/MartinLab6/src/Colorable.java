/*
*Programmer: Hunter Martin
*Course: COSC 211 Winter'24") 
*Due Date: 2-22-24
*
*Description: This is the interface that is called colorable with one method inside which is "howToColor":. 
*/
public interface Colorable {
	 void howToColor();
}
